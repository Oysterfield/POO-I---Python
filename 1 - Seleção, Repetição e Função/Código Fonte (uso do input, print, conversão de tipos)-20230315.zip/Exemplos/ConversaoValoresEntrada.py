#Funções para conversão de valores

# Converte uma string para número inteiro correspondente
a = int('456')
print("a ",a,type(a))

# Converte uma string para número real correspondente
b = float('3.14153')
print("b ",b,type(b))

# Converte um número inteiro para uma string
c = str(345)
print("c ",c,type(c))

# Converte um número real para uma string
d = str(5.6789)
print("d ",d,type(d))


